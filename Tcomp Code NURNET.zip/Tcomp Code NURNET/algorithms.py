import numpy as np
import torch
import torch.nn as nn
from utils.utils_loss import logistic_loss
import torch.nn.functional as F
from utils.utils_algo import update_ema, exp_rampup

def TcompUnbiased(model, given_train_loader, test_loader, args, loss_fn, device, unbiased):
    test_acc = accuracy_check(loader=test_loader, model=model, device=device)
    print('#epoch 0', ': test_accuracy', test_acc)
    t = 1
    lamda = 0
    test_acc_list = []
    train_acc_list = []
    test_acc_list1 = []
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)
    prior = args.prior

    #损失函数中系数
    tau_s =prior**3+ prior**2*(1-prior) + prior*(1-prior)**2 + (1-prior)**3
    t1 = (prior*(1-(1-prior)*prior))/ tau_s
    t2 = (1-prior)**3/ tau_s
    t3 = prior**2/ tau_s
    t4 = (1-prior)**2/ tau_s
    t5 = prior**3/ tau_s
    t6 = ((1-prior)*(1-(1-prior)*prior))/ tau_s

    A = t1**2 + t3**2 + t5**2
    B = t1*t2 + t3*t4 + t5*t6
    C = t2**2 + t4**2 + t6**2

    Ca = (t1 * C - t2 * B)/ (A * C - B**2)
    Cb = (-t1 * B + t2 * A)/ (A * C - B**2)
    Cc = (t3 * C - t4 * B)/ (A * C - B**2)
    Cd = (-t3 * B + t4 * A)/ (A * C - B**2)
    Ce = (t5 * C - t6 * B)/ (A * C - B**2)
    Cf = (-t5 * B + t6 * A)/ (A * C - B**2)


    #训练过程
    for epoch in range(args.ep):
        #启用 batch normalization 和 dropout
        model.train()
        for (X, y) in given_train_loader:
            X, y = X.to(device), y.to(device)
            #梯度先设置为0
            optimizer.zero_grad()
            outputs = model(X)[:,0]
            a_index, b_index, c_index = (y == 1), (y == -1), (y == 0)
            a_train_loss, b_train_loss, c_train_loss = 0.0, 0.0, 0.0
            if a_index.sum() > 0 :
                a_train_loss = ( Ca * prior * loss_fn(outputs[a_index]) + Cb * ( 1-prior ) * loss_fn(-outputs[a_index])).mean()
            if b_index.sum() > 0 :
                b_train_loss = ( Cc * prior * loss_fn(outputs[b_index]) + Cd * ( 1-prior ) * loss_fn(-outputs[b_index])).mean()
            if c_index.sum() > 0 :
                c_train_loss = ( Ce * prior * loss_fn(outputs[c_index]) + Cf * ( 1-prior ) * loss_fn(-outputs[c_index])).mean()
            train_loss1 = a_train_loss + b_train_loss + c_train_loss
            if unbiased == True:
                train_loss = train_loss1
            else:
                if train_loss1 < 0:
                    train_loss = train_loss1 + lamda * (-train_loss1) ** t
                else:
                    train_loss = train_loss1
            train_loss.backward()
            optimizer.step()
        model.eval()
        test_acc = accuracy_check(loader=test_loader, model=model, device= device)
        print('#epoch', epoch+1, ': train_loss', train_loss.data.item(), 'test_accuracy', test_acc)
        if epoch >= (args.ep - 10):
            test_acc_list1.extend([test_acc])
        train_acc_list.extend([train_loss])
        test_acc_list.extend([test_acc])
    return train_acc_list, test_acc_list, np.mean(test_acc_list1)


def  accuracy_check(loader, model, device):
    #用于神经网络推理阶段，表示不需要计算梯度。
    with torch.no_grad():
        total, num_samples = 0, 0
        for images, labels in loader:
            labels, images = labels.to(device), images.to(device)
            outputs = model(images)[:,0]
            predicted = (outputs.data >= 0).float()
            predicted[predicted == 0] = -1.0
            total += (predicted == labels).sum().item()
            #label是维度(N,1)的整数，返回N
            num_samples += labels.size(0)
    return total / num_samples
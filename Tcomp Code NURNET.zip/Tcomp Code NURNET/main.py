import numpy as np
import torch
from utils.utils_data import generate_Tcomp_loaders, get_model, generate_Tcomp_data
import argparse
import os
from utils.utils_models import linear_model, mlp_model
from utils.utils_loss import logistic_loss, sigmoid_loss
from algorithms import *

import matplotlib
import matplotlib.pyplot as plt

i = 0
Acc_list = []

for i in range(0,10) :
    unbiased = True
    parser = argparse.ArgumentParser()

    parser.add_argument('-lr', help='optimizer\'s learning rate', default=1e-4, type=float)
    parser.add_argument('-bs', help='batch_size of ordinary labels.', default=2000, type=int)
    parser.add_argument('-ds', help='specify a dataset', default='cifar10', type=str, required=False)
    parser.add_argument('-mo', help='model name', default='resnet', choices=['linear', 'mlp', 'resnet'], type=str, required=False)
    parser.add_argument('-ep', help='number of epochs', type=int, default=100)
    parser.add_argument('-wd', help='weight decay', default=1e-4, type=float)
    parser.add_argument('-lo', help='specify a loss function', default='sigmoid', type=str, choices=['logistic', 'sigmoid', 'cross'], required=False)
    parser.add_argument('-me', help='specify a method', default='TcompUnbiased', type=str, choices=['TcompUnbiased'], required=False)
    parser.add_argument('-n', help = 'number of unlabeled data pairs', default=15000, type=int, required=False)
    parser.add_argument('-prior', help = 'class (positive) prior', default=0.8, type=float, required=False)
    parser.add_argument('-gpu', help = 'used gpu id', default='0', type=str, required=False)

    args = parser.parse_args()
    device = torch.device("cuda:"+args.gpu if torch.cuda.is_available() else "cpu")

    if args.lo == 'logistic':
        loss_fn = logistic_loss

    if args.lo == 'sigmoid':
        loss_fn = sigmoid_loss

    if args.ds == 'mnist' or args.ds == 'kmnist' or args.ds == 'fashion':
        args.n =4000
    elif args.ds == 'cifar10':
        args.n = 4000
    elif args.ds == 'svhn':
        args.n = 5500


    def build_file_name(dataset, method,  prior, loss,  unbiased, phase, figure):
        if figure:
            format = '.png'
        else:
            format = '.txt'
        return (os.path.dirname(os.path.realpath(__file__)) +
                '/output/' + dataset + '/' +
                method + '_' +
                str(prior) + '_' +
                loss + '_' +
                unbiased + '_' +
                phase + '_' + format)

    def plot_loss(np_loss_test, np_loss_train, nb_epoch):
        plt.xlim(1, nb_epoch, 1)
        plt.plot(range(1, nb_epoch+1), np_loss_test, label='Test')
        plt.plot(range(1, nb_epoch+1), np_loss_train, label='Train')
        plt.title('Loss over ' + str(nb_epoch) + ' Epochs', size=15)
        plt.legend()
        plt.grid(True)
        #绘制损失函数的图像

    xa, xb, xc,given_ya, given_yb, given_yc, xt, yt, dim = generate_Tcomp_data(args)

    given_train_loader,  test_loader = generate_Tcomp_loaders(xa, xb, xc, given_ya, given_yb, given_yc, xt, yt, args.bs)
    model = get_model(args, dim, device)

    loss_train, loss_test, Acc = TcompUnbiased(model, given_train_loader, test_loader, args, loss_fn, device,unbiased)
    print("TcompUnbiased Accuracy:", Acc)

    np_loss_test = np.array(loss_test)
    np_loss_train = np.array(loss_train)
    if args.me == 'TcompUnbiased':
        loss_test_file = build_file_name(args.ds, args.me, args.prior, args.lo,  unbiased = str(unbiased), phase='test', figure=False)
        loss_train_file = build_file_name(args.ds, args.me, args.prior, args.lo, unbiased = str(unbiased), phase='train', figure=False)
    else:
        loss_test_file = build_file_name(args.ds, args.me, args.prior, args.lo,unbiased = str(unbiased), phase='test', figure=False)
        loss_train_file = build_file_name(args.ds, args.me, args.prior, args.lo,unbiased = str(unbiased), phase='train', figure=False)
    np.savetxt(loss_test_file, np_loss_test, newline="\r\n")
    np.savetxt(loss_train_file, np_loss_train, newline="\r\n")

    plot_loss(np_loss_test, np_loss_train, args.ep)
    figure_file = build_file_name(args.ds, args.me, args.prior, args.lo, unbiased = str(unbiased), phase='test', figure=True)
    plt.savefig(figure_file)

    print('method:{}    lr:{}    wd:{}'.format(args.me, args.lr, args.wd))
    print('loss:{}    prior:{}'.format(args.lo, args.prior))
    print('model:{}    dataset:{}'.format(args.mo, args.ds))
    print('num of sample:{}'.format(args.n))

mean = np.mean(Acc_list)
std = np.std(Acc_list)
print('mean:', mean,  'std:', std )